package library_management;

import java.util.ArrayList;

//Interface for Library Item
public interface LibraryItem {
 void addItem(String item);
 boolean searchItem(String item);
 void removeItem(String item);
}




