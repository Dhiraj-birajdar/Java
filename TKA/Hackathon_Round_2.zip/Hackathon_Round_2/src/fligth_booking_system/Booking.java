package fligth_booking_system;


//Interface for Booking
public interface Booking {
void bookTicket();
}
