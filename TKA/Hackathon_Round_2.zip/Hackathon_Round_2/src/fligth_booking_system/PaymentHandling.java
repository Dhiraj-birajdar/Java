package fligth_booking_system;

//Interface for handling payments
public interface PaymentHandling {
void makePayment();
}
